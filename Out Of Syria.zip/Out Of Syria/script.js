var amir = new Object();
amir.medicaments = false
amir.batterie = false
amir.argent = false
amir.heure = 6;
amir.minute = 7;
amir.flag = false;

function heure(heure, minute) {
    var res = heure
   if(heure < 10){
     heure = "0"+heure
   }
   if(minute < 10){
    minute = "0"+minute
   }
   return res = heure +":"+minute
}

function ajouterDialogue(speaker, phrase) {
    var para = document.createElement("div");
    var node = document.createElement("p");
    var img = document.createElement("img");
    var time = document.createElement("span")
    var element = document.getElementById("jeu");
     img.src = 'img/'+speaker+'.png'

    if (speaker == "amir") {
        para.className = "message darker"
        img.className ="right"
        time.className = "time-left"
    }
    else{
        para.className = "message ligther"
        img.className ="left"
        time.className = "time-right"
    }
    time.innerHTML = heure(amir.heure, amir.minute)
    node.innerHTML = phrase
    para.appendChild(img)
    para.appendChild(node);
    para.appendChild(time)
    element.appendChild(para);
    bottom()
}


function ajouterChoix(choix) {
    choix.forEach(function(item,index) {
       document.getElementById("jeu").innerHTML+= '<button type="button" onclick="test('+index+')" class="btn btn-primary" style=" display: block; margin : auto; margin-bottom: 10px">'+item+'</button>'
    });

    bottom();

}

function narrateur(argument) {
    document.getElementById("jeu").innerHTML+= '<div class="alert alert-dismissible alert-info"> <p style="text-align: center; height: 10px">'+ argument +'</p> </div>'
    bottom();
}

function test(argument) {
    amir.flag = true
    console.log(amir.flag)
    console.log(argument)
}

function bottom () {
    scrollingElement = (document.scrollingElement || document.body)

   $(scrollingElement).animate({
      scrollTop: document.body.scrollHeight
   }, 500);
}