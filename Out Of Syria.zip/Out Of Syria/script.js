var amir = new Object();
amir.medicaments = false
amir.batterie = false
amir.argent = false
amir.heure = 6;
amir.minute = 7
amir.trousseDeSoins = false;
amir.argent = false;
amir.telephone = false;


//Fonction pour mettre en place le format de l'heure
function heure(heure, minute) {
    var res = heure
   if(heure < 10){
     heure = "0"+heure
   }
   if(minute < 10){
    minute = "0"+minute
   }
   return res = heure +":"+minute
}

//Ajouter le nombre de minutes à une heure
function ajouterMinute(heureDeBase,minuteDeBase, minuteAAjouter){
  minuteDeBase += minuteAAjouter
  if(minuteDeBase >= 60){
    heureDeBase += Math.trunc(minuteDeBase / 60)
    minuteDeBase = minuteDeBase % 60
  }
  if(heureDeBase >= 24){
    heureDeBase = 0;
  }
  return [heureDeBase, minuteDeBase]
}

//Ajouter un nouveau dialogue
//Speaker = nom des images sans le format
//Minute a ajouter par rapport au dernier dialogue
function ajouterDialogue(speaker, phrase, minuteAAjouter) {
    var para = document.createElement("div");
    var node = document.createElement("p");
    var img = document.createElement("img");
    var time = document.createElement("span")
    var element = document.getElementById("jeu");
     img.src = 'img/'+speaker+'.png'

    if (speaker == "amir" || speaker =="choix") {
        para.className = "message darker"
        img.className ="right"
        time.className = "time-left"
    }
    else{
        para.className = "message ligther"
        img.className ="left"
        time.className = "time-right"
    }
    tab = ajouterMinute(amir.heure,amir.minute, minuteAAjouter)
    amir.heure = tab[0]
    amir.minute = tab[1]
    time.innerHTML = heure(amir.heure, amir.minute)
    node.innerHTML = phrase
    para.appendChild(img)
    para.appendChild(node);
    para.appendChild(time)
    element.appendChild(para);
    bottom()
}

//Ajouter un nouveau choix
function ajouterChoix() {
   var valeur = prompt("Faites votre choix en tapant le numéro du choix")
   console.log(valeur)
   bottom();
   return valeur
}

function narrateur(argument) {
    document.getElementById("jeu").innerHTML+= '<div class="alert alert-dismissible alert-info"> <p style="text-align: center; height: 10px">'+ argument +'</p> </div>'
    bottom();
}

function test(argument) {
    amir.flag = true
    console.log(amir.flag)
    console.log(argument)
}

function bottom () {
    scrollingElement = (document.scrollingElement || document.body)

   $(scrollingElement).animate({
      scrollTop: document.body.scrollHeight
   }, 500);
}

function dialogue(speaker, phrase, nbMinute) {
  if(speaker == "narrateur"){
    setTimeout(function(){
    narrateur(phrase)
  },delay = delay + phrase.length/7*1000);
  }
  else{
    setTimeout(function(){
    ajouterDialogue(speaker,phrase,0)
  },delay = delay + phrase.length/7*1000);
  }
  
}