var delay = 16000;

dialogue("narrateur","Dans la chambre d'Amir et Nour")
dialogue("amir","Réveille-toi chérie, il est temps de quitter la Syrie",0)










/*
phrase = "Tu as raison Amir. Va préparer tes affaires, je vais réveiller notre fille"
setTimeout(function(){
ajouterDialogue("nour",phrase,0)
},delay = delay + phrase.length/8*1000);

phrase = "Dans la chambre de Lina"



setTimeout(function(){
ajouterDialogue("nour","Lina ! Réveille-toi !",2)
},delay = delay + phrase.length/8*1000);

setTimeout(function(){
ajouterDialogue("lina","Qu'est-ce qui se passe maman ?",0)
},delay = delay + phrase.length/8*1000);
phrase.length/8*1000
setTimeout(function(){
ajouterDialogue("nour","Habille-toi vite et attends-nous devant la porte",0)
},delay = delay + phrase.length/8*1000);

setTimeout(function(){
narrateur("Dans la chambre d'Amir et Nour")
},delay = delay + 1800);

setTimeout(function(){
ajouterDialogue("amir","Que prendre pour notre voyage ?",2)
},delay = delay + 1500);

setTimeout(function(){
ajouterDialogue("amir","J'ai le choix entre le téléphone, prendre de l'argent ou prendre une trousse de soins",0)
},delay = delay + 1500);

setTimeout(function(){
ajouterDialogue("choix","1) Prendre le téléphone</br>2) Prendre de l'argent</br>3) Prendre une trousse de soins",0)
},delay = delay + 1900);

setTimeout(function(){
	choix = ajouterChoix()
	if(choix == 1) amir.telephone = true;
	if(choix == 2) amir.argent = true;
	if(choix == 3) amir.trousseDeSoins = true;
},delay = delay + 2000);

setTimeout(function(){
	var phrase = ""
	if(amir.telephone) phrase = "Je vais prendre le téléphone, ça peut toujours servir";
	if(amir.argent) phrase = "L'argent peux nous aider à la frontière";
	if(amir.trousseDeSoins) phrase ="Avoir une trousse de soins peux être utile";
ajouterDialogue("amir", phrase,0)
},delay = delay + 12000);

setTimeout(function(){
narrateur("Devant la porte d'entrée")
},delay = delay + 2000);

setTimeout(function(){
ajouterDialogue("amir","On a le choix entre l'avion, le bateau ou le bus pour quitter ce pays",5)
},delay = delay + 2500);

setTimeout(function(){
ajouterDialogue("nour","L'avion est le moyen le plus rapide mais on risque d'avoir des problèmes à la douane",0)
},delay = delay + 2500);

setTimeout(function(){
ajouterDialogue("amir","Tu as raison Nour, je pense que le bateau est le meilleur moyen",1)
},delay = delay + 2500);

setTimeout(function(){
ajouterDialogue("nour","Tu veux prendre le bateau où ? On est en plein milieu du désert !",0)
},delay = delay + 2500);

setTimeout(function(){
ajouterDialogue("amir","Calme-toi Nour ! J'ai pensé aller à Beyrouth pour prendre le bateau. Il paraît que si on laisse un petit quelque chose à un marin, il nous laisse embarquer",0)
},delay = delay + 2500);

setTimeout(function(){
ajouterDialogue("nour","C'est aussi se faire attraper par les gardes-côtes...",0)
},delay = delay + 2500);

setTimeout(function(){
ajouterDialogue("nour","Ou sinon il y a le bus. Moins cher et plus sûr que le bateau",1)
},delay = delay + 2500);

setTimeout(function(){
ajouterDialogue("amir","Oui, mais il y a aussi le problème de la frontière",0)
},delay = delay + 2500);

setTimeout(function(){
ajouterDialogue("choix","1) Aller en bateau</br>2) Prendre l'avion</br>3) Prendre le bus",0)
},delay = delay + 2500);

*/