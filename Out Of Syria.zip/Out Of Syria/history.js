var delay = 7000;

setTimeout(function(){
narrateur("Dans la chambre d'Amir et Nour")
},delay = delay + 1000);

setTimeout(function(){
ajouterDialogue("amir","Réveille-toi chérie, il est temps de quitter la Syrie")
},delay = delay + 1500);

setTimeout(function(){
ajouterDialogue("nour","Tu as raison Amir. Va préparer tes affaires, je vais réveiller notre fille")
},delay = delay + 1800);

setTimeout(function(){
narrateur("Dans la chambre de Lina")
},delay = delay + 1000);

setTimeout(function(){
ajouterDialogue("nour","Lina ! Réveille-toi !")
},delay = delay + 1800);

setTimeout(function(){
ajouterDialogue("lina","Qu'est-ce qui se passe maman ?")
},delay = delay + 1800);

setTimeout(function(){
ajouterDialogue("nour","Habille-toi vite et attends-nous devant la porte")
},delay = delay + 1800);

setTimeout(function(){
narrateur("Dans la chambre d'Amir et Nour")
},delay = delay + 1000);

setTimeout(function(){
ajouterDialogue("amir","Que prendre pour notre voyage ?")
},delay = delay + 1500);

setTimeout(function(){
ajouterChoix(["Prendre le téléphone","Prendre une trousse de soins","Prendre de l'argent"])
},delay = delay + 1500);

setTimeout(function(){
console.log(amir.flag)
},delay = delay + 1500);


