def contour(phrase):
	for i in range(len(phrase)+2):
		print("-",end='')
	print()
	print("|"+phrase+"|")
	for i in range(len(phrase)+2):
		print("-",end='')
	print()