from contour import *
from amir import *
import time
import sys
def choix1(amir):
	print("Aujourd'hui, c'est le grand jour. J'ai réveillé ma famille à 5h du matin afin de m'enfuir.")
	print("J'ai pris mon téléphone et des vivres. Il me reste de la place pour un objet")
	print()
	print("1) Prendre une batterie")
	print("2) Prendre des médicaments")
	print("3) Prendre de l'argent")
	print()
	choix = input("Votre choix : ")
	print()
	if(choix == "1") : 
		amir.batterie = True
		print("Une batterie de secours peux me servir.")
	if(choix == "2") :
		amir.medicaments = True
		print("Prendre des médicaments peux s'avérer utile.")
	if(choix == "3") :
		amir.argent = True
		print("Avoir de l'argent peux nous aider à la frontière")
	print()
	

def choix2(amir):
	if(amir.tenterDePrendreLAvion):
		print("On retombe au point de départ avec le choix entre le bus ou le bateau")
		print()
		print("1) Aller en bus en traversant la Syrie")
		print("2) Aller jusqu'à Beyrouth")
	else:
		print("En sortant de chez nous, ma fille me demande quelle trajet allons nous choisir.\nMa femme essaya de me persuader en voulant partir à Beyrouth pour prendre le bateau et arriver en Grèce.")
		print()
		print("1) Aller en bus en traversant la Syrie")
		print("2) Aller jusqu'à Beyrouth")
		print("3) Aller à l'aéroport de Damas")
	print()
	choix = input("Votre choix : ")
	print()
	if(choix == "1") : 
		amir.bus = True
		print("Prendre le bus est la solution la plus sécurisée")
	if(choix == "2") :
		amir.bateau = True
		print("Prendre le bateau est la solution la plus rapide pour fuir le pays")
	if(choix == "3" and not amir.tenterDePrendreLAvion) :
		amir.avion = True
		print("J'espère qu'on aura pas de problème à la douane")
	print()

def choix3(amir):
	if(amir.avion):
		print("On décide donc d'aller à l'aéroport de Damas.\nHeuresement que ce n'est pas loin de chez moi. Pour cela, on prends le taxi.\nManque de chance, on tombe sur un barrage")
		print()
		print("1) Essayer de convaincre la police")
		print("2) Verser un pot-de-vin à la police")
		print("3) Faire demi-tour")
		print()
		choix = input("Votre choix : ")
		print()
		if(choix == "1"):
			print("Après une dizaine de minute avec la police, je n'aboutis à rien. Suite à ça, la police a vu ma petite fille qui pleurais et décida de nous laisser passer.")
			amir.argent = True
			amir.barrageAeroportPasser = True
		if(choix == "2" and not amir.argent):
			print("Je n'ai pas d'argent pour leur verser un pot-de-vin. J'ai tenté de leur faire croire que j'avais de l'argent, mais cela n'a pas fonctionné. Ma famille et moi sommes en prison")
			print()
			print("Fin de la partie")
			sys.exit()
		if(choix == "2" and amir.argent):
			print("J'ai donné l'argent que j'avais mis de côté. Maintenant, je n'ai plus un sou")
			amir.argent=False
			amir.barrageAeroportPasser = True
		if(choix == "3"):
			print("Je dis à ma famille qu'on va essayer un autre moyen et on va probablement choisir un autre moyen de quitter le pays")
			#
			# METTRE ICI SI YA UN AUTRE CHEMIN
			#
		print()
		if(amir.barrageAeroportPasser and amir.argent):
			print("Nous avons réussi à passer la frontière sans trop de soucis. Nous voilà donc à l'aéroport pour acheter les billets pour prendre la direction de l'Italie. Je demande à l'accueil le prix des billets et je m'aperçois que j'ai assez uniquement pour deux personnes. Ma femme me proposa de la laisser seule car je pourrais protéger notre fille en cas de danger.")
			print()
			print("1) Payer pour vous et votre fille")
			print("2) Payer pour vous et votre femme")
			print("3) Payer pour votre fille et votre femme")
			print()
			choix = input("Votre choix : ")
			print()
			if(choix == "1"):
				print("J'ai décidé de payer pour ma fille et moi-même afin de la protéger. Or nos passeports ne sont plus valides")
			if(choix == "2"):
				print("J'ai décidé de payer pour ma femme et moi-même et laisser notre fille toute seule. Or nos passeports ne sont plus valides")
			if(choix == "3"):
				print("J'ai décidé de payer pour ma fille et ma femme pour les mettre en sécurité. Or nos passeports ne sont plus valides")
			print("On est obligé de faire demi-tour")
		if(amir.barrageAeroportPasser and not amir.argent):
			print("Nous avons réussi à passer la frontière sans trop de soucis. Nous voilà donc à l'aéroport pour acheter les billets. Je demande à l'accueil le prix des billets et je m'aperçois que j'ai assez uniquement pour une seule personne")
			print()
			print("1) Payer pour vous")
			print("2) Payer pour votre femme")
			print("3) Payer pour votre fille")
			print("4) Faire demi-tour")
			print()
			choix = input("Votre choix : ")
			print()
			if(choix !="4"):
				print("J'étais sur le point d'acheter le billet or le passeport n'est plus valide. Nous sommes obligés de faire demi-tour")
			else:
				print("Je pense que faire demi-tour est la meilleure option")
		amir.tenterDePrendreLAvion = True
		choix2(amir)