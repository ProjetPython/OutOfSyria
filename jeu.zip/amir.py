class Amir():
	def __init__(self):
		self.prenom = "Amir"
		self.age =30
		self.ville="Damas"
		self.ptVie=100
		self.batterie=False
		self.medicaments=False
		self.bus=False
		self.bateau=False
		self.avion=False
		self.argent=False
		self.barrageAeroportPasser=False
		self.tenterDePrendreLAvion=False